<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spritesheet2" tilewidth="48" tileheight="48" tilecount="256" columns="16">
 <image source="../images/spritesheet.png" width="768" height="768"/>
</tileset>
