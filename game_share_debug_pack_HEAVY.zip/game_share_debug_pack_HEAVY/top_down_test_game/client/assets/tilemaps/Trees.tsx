<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Trees" tilewidth="48" tileheight="48" tilecount="256" columns="16">
 <image source="X:/RPG Maker/Projects/TestProject/img/tilesets/Trees.png" width="768" height="768"/>
 <tile id="67">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="132">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="144">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="180">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
