<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Nimar INN" tilewidth="48" tileheight="48" tilecount="1260" columns="30">
 <image source="../images/Nimar INN.png" width="1440" height="2016"/>
</tileset>
