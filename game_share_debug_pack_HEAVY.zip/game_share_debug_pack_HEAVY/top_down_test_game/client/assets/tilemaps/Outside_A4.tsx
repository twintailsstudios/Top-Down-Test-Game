<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Outside_A4" tilewidth="48" tileheight="48" tilecount="240" columns="16">
 <image source="../images/Outside_A4.png" width="768" height="720"/>
</tileset>
