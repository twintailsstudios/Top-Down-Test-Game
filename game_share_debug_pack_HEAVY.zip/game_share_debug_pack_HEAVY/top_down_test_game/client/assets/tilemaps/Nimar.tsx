<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Nimar" tilewidth="48" tileheight="48" tilecount="3025" columns="55">
 <image source="../images/Nimar.png" width="2640" height="2640"/>
</tileset>
