<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Outside_A5" tilewidth="48" tileheight="48" tilecount="128" columns="8">
 <image source="X:/RPG Maker/Projects/TestProject/img/tilesets/Outside_A5.png" width="384" height="768"/>
 <tile id="112">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="117">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="118">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="119">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="120">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="121">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="collide" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
