<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Outside_A2" tilewidth="48" tileheight="48" tilecount="192" columns="16">
 <image source="X:/RPG Maker/Projects/TestProject/img/tilesets/Outside_A2.png" width="768" height="576"/>
</tileset>
