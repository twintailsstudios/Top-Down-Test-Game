<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Outside_B" tilewidth="48" tileheight="48" tilecount="256" columns="16">
 <image source="X:/RPG Maker/Projects/TestProject/img/tilesets/Outside_B.png" width="768" height="768"/>
</tileset>
