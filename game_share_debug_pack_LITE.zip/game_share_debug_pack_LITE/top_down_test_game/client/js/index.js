/////creating universal variables/////
let blocked;
var player;
var playerCount = 1;
var playerCountText;
let controls = {};
let gameover = 0;
let collider;
let player_id;
let send_data = null;
let go;
let debug = false;

/////configuring game state/////
const config = {
    type: Phaser.AUTO,
    width: 960,
    height: 960,
    physics: {
        default: 'arcade',
        arcade: {
            debug: debug
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};
///create game////
const game = new Phaser.Game(config);

function preload() {

/////is supposed to display loading bar? I'm not sure if this is working right..../////
    this.load.on('fileprogress', function (file, value) {
        console.log(value);
    });

    this.load.on('complete', function () {

        // progress.destroy();

    });
/////actually preloads resources to use in game/////
    this.load.audio('bgm_calm', 'top_down_test_game/assets/music/Electrodoodle.mp3');
 		this.load.image('level1', 'top_down_test_game/assets/tilemaps/level1.png');
		this.load.image('emptypot', 'top_down_test_game/assets/images/emptypot.png');
		this.load.image('filledbucket', 'top_down_test_game/assets/images/filledbucket.png');
		this.load.image('player', 'top_down_test_game/assets/images/player.png');
		this.load.image('doorleft', 'top_down_test_game/assets/images/doorleft.png');
		this.load.image('doorright', 'top_down_test_game/assets/images/doorright.png');
		this.load.image('tent', 'top_down_test_game/assets/images/tent.png');
		this.load.image('sign', 'top_down_test_game/assets/images/sign.png');
		this.load.image('campfire', 'top_down_test_game/assets/images/campfire.png');
		this.load.image('woodpile', 'top_down_test_game/assets/images/woodpile.png');
		this.load.image('tree', 'top_down_test_game/assets/images/tree.png');
		this.load.image('rock', 'top_down_test_game/assets/images/rock.png');
		this.load.image('grapes', 'top_down_test_game/assets/images/grapes.png');
		this.load.image('log', 'top_down_test_game/assets/images/log.png');
	this.load.spritesheet('gameTiles1', 'top_down_test_game/assets/images/Outside_A2.png',{frameWidth: 48, frameHeight: 48});
	this.load.spritesheet('gameTiles2', 'top_down_test_game/assets/images/Outside_B.png',{frameWidth: 48, frameHeight: 48});
	this.load.spritesheet('dude', 'top_down_test_game/assets/spritesheets/dude.png',{frameWidth: 32, frameHeight: 48});
    this.load.spritesheet('dude2', 'top_down_test_game/assets/spritesheets/dude.png',{frameWidth: 32, frameHeight: 48});


}

function create() {
    const game = this;
/////plays music/////
    let background_music = this.sound.add('bgm_calm');
    background_music.volume = 0.05;
    background_music.loop = true;
    background_music.play();
    this.add.image(480, 480, 'level1');
////makes all the objects you can't walk through/////
    blocked = this.physics.add.staticGroup();

/////actually assigns locations to specific objects preloaded above///
	blocked.create(456, 216, 'sign');
	blocked.create(648, 168, 'woodpile');
	blocked.create(648, 216, 'campfire');
	blocked.create(744, 174, 'tent');
	blocked.create(840, 216, 'filledbucket');
	blocked.create(600, 400, 'rock');
	blocked.create(648, 448, 'rock');
	blocked.create(600, 448, 'grapes');
	blocked.create(214, 720, 'tree');
	blocked.create(214, 552, 'tree');
	blocked.create(214, 384, 'tree');
	blocked.create(214, 286, 'log');
	blocked.create(214, 192, 'tree');
	blocked.create(358, 192, 'tree');

////gives physics to player so that they will obey blocked objects/////
    player = this.physics.add.sprite(480, 480, 'dude');
/////tells game to look at arrow keys for game input/////
	cursors = this.input.keyboard.createCursorKeys();
/////makes it so player can't leave the edges of the map/////
    player.setOffset(5, 13);
    player.setBounce(0.1);
    player.setCollideWorldBounds(true);

/////creates the available animations to call on when moving sprites/////
    this.anims.create({
        key: 'otherleft',
        frames: this.anims.generateFrameNumbers('dude2', {start: 0, end: 3}),
        frameRate: 10,
        repeat: -1
    });

    this.anims.create({
        key: 'otherturn',
        frames: [{key: 'dude2', frame: 4}],
        frameRate: 20
    });

    this.anims.create({
        key: 'otherright',
        frames: this.anims.generateFrameNumbers('dude2', {start: 5, end: 8}),
        frameRate: 10,
        repeat: -1
    });

    this.anims.create({
        key: 'left',
        frames: this.anims.generateFrameNumbers('dude', {start: 0, end: 3}),
        frameRate: 10,
        repeat: -1
    });

    this.anims.create({
        key: 'turn',
        frames: [{key: 'dude', frame: 4}],
        frameRate: 20
    });

    this.anims.create({
        key: 'right',
        frames: this.anims.generateFrameNumbers('dude', {start: 5, end: 8}),
        frameRate: 10,
        repeat: -1
    });
    go = this;
    collider = this.physics.add.collider(player, blocked);
	controls.velocity = player.body.velocity;
	////will soon display how many people are connected/////
	playerCountText = this.add.text(16, 70, 'Players: Connecting...', {fontSize: '30px', fill: '#000'});

/////call start_multiplayer function in multiplayer.js file/////
	send_data = start_multiplayer();


}




function update() {
////if an arrow key is pressed, move player in appropriate direction////    
        if (cursors.left.isDown) {
            player.setVelocityX(-160);
				emit_movement();
            player.anims.play('left', true);
        }
        else if (cursors.right.isDown) {
            player.setVelocityX(160);
				emit_movement();
            player.anims.play('right', true);
        }
        else if (cursors.up.isDown) {
			player.setVelocityY(-160);
					emit_movement();
			player.anims.play('right', true);
		}
		else if (cursors.down.isDown) {
			player.setVelocityY(160);
					emit_movement();
			player.anims.play('left', true);
		}
		else{
			player.setVelocityX(0);
			player.setVelocityY(0);
				//emit_movement();
			player.anims.play('turn');
		}
	
	
////haven't figured out what this is for yet...but seems important////
////Has something to do with updating player movements for other clients?///
        for (let id in remote_players) {
            if (remote_players.hasOwnProperty(id)) {
                if (remote_players[id].player && remote_players[id].movement) {
                    update_movement(remote_players[id].player, remote_players[id].movement);
                }
            }

        }
}